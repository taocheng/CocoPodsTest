//
//  main.m
//  CocoPodsTest
//
//  Created by 陶澄 on 16/3/16.
//  Copyright © 2016年 陶澄. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
